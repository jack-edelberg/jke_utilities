# JKE's Utilities
This is a collection of functions I have built for use in projects that I believe might be useful again in the future!

## Table of contents
1. Linear Interpolation
2. Rolling Average
3. Subplot by Category
