# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['jke_utilities']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.0,<4.0.0',
 'numpy>=1.23.3,<2.0.0',
 'pandas>=1.5.0,<2.0.0',
 'seaborn>=0.12.0,<0.13.0']

setup_kwargs = {
    'name': 'jke-utilities',
    'version': '0.1.0',
    'description': 'Collection of reusable functions written by Jack Kolberg-Edelbrock',
    'long_description': "# JKE's Utilities\nThis is a collection of functions I have built for use in projects that I believe might be useful again in the future!\n\n## Table of contents\n1. Linear Interpolation\n2. Rolling Average\n3. Subplot by Category\n",
    'author': 'Jack Kolberg-Edelbrock',
    'author_email': 'jack.edelbrock@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
